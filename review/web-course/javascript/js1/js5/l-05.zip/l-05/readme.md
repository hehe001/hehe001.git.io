location.href  获取 当前 url
keyword=test
如果有某个参数值的时候  让页面中的div 显示出来

name=xhanglu&class=1603&abc=32

name 值是多少
class 班级是多少
abc 是多少





